read me

There is my submission of nlp hw1

q1
I modified the python code to find patterns, to use this code,
for example, finding word with a suffix s, use the following 
command:
suffix.py ‘’  ‘s’ ./../gutenberg/*.txt’

for details of explanation, please refer to the nlp1.doc file in 
./q1 folder

q2
the unvowel.txt, squash.txt and edit.txt files are in the ./q2
folder, the result of counting and revoweling is in the folder 
./q2/results/, for details and statistics, please refer to the
./q2/nlp2.doc

q3
I implemented the FST by openfst, the fst file is in ./q3 fst.txt 
is the definition and ./q3/fst.fst is the compiled fst. mysyms.syms
is the input and output symbols, fstsvg.svg and fstpng.png is the graph
presentation of the fst. 