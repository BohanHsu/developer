package test;

import utility.RandomNumberGenerator;

public class TestRamdomGenerator {
	public static void main(String[] args) {
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
		System.out.println(RandomNumberGenerator.randomIntTo(200));
	}
}
