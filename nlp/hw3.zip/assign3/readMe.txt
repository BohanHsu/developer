hw3

Please use the command line:
java -jar ./parse.jar grammar_path start_symbol sentence
here is an example:
java -jar ./parse.jar ./../assign2/grammar1.txt S1 another swallow each has servant .
